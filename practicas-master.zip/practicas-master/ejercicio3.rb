#Definir Variables 

title = "Título del post"
puts title
description = "Descrípción del post"
puts description
number_9f_likes = 10
puts number_9f_likes
NUM_OF_POST = 1
puts NUM_OF_POST

street = "Calle principal"
number = "207"
state = "Puebla"
city = "Cholula"
zip = "75841"
puts "Dirección: #{street} #{number} #{city}, #{state} C.P. #{zip}"

=begin
PRUEBAS

PS C:\Users\paexb\desktop\codea> ruby ejercicio3.rb
Título del post
Descrípción del post
10
1
Dirección: Calle principal 207 Cholula, Puebla C.P. 75841
PS C:\Users\paexb\desktop\codea>

=end
