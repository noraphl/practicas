#Ejercicio - Obtener Una Palabra

utiles = [["libro", "libreta", "cuaderno"], ["carpeta", "folder"]]

p utiles[1][0]

=begin
PRUEBAS 

PS C:\Users\paexb\desktop\codea> ruby ejercicio_m1.rb
"carpeta"
PS C:\Users\paexb\desktop\codea>

=end