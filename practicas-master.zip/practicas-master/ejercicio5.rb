=begin
	Ejercicio Operaciones Aritmeticas	
=end

num1 = 100
num2 = 31
 
sum = num1 + num2
puts "Suma: #{num1} + #{num2} = #{sum}"
difference = num1 - num2
puts "Resta: #{num1} - #{num2} = #{difference}"
product = num1 * num2 
puts "Multiplicación: #{num1} * #{num2} = #{product}"
quotient = num1 / num2.to_f
puts "División: #{num1} / #{num2} = #{quotient}"
modulus = num1 % num2
puts "Módulo: #{num1} % #{num2} = #{modulus}"