edad = 75
sexo = "hombre"

puts "Hombre Adulto Mayor"  if edad >= 70 
