numero = 3
unless numero 
   puts "El numero no existe"
else
   puts "El numero es 3"
end