#Ejercicio - Nombre Correcto

first_name = "Rogelio"
last_name = "manzano"
mensaje = "Nombre Correcto"

puts mensaje.downcase if first_name.upcase == "ROGELIO" && last_name.capitalize == "Manzano"

=begin

PS C:\Users\paexb\desktop\codea> ruby nomb_correcto.rb
nombre correcto
PS C:\Users\paexb\desktop\codea>

=end