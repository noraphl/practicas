#Ejercicio - Mensaje de Bienvenida

first_name = "Roberto"
last_name = "Monroe"
gender = "M"

puts "Welcome #{first_name}, your last_name is '#{last_name}' and your gender is #{gender}"

=begin
PRUEBAS

PS C:\Users\paexb\desktop\codea> ruby ejercicio11.rb
Welcome Roberto, your last_name is 'Monroe' and your gender is M
PS C:\Users\paexb\desktop\codea>

=end
